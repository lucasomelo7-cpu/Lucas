# springboot-frontvagas

Interface web em Spring Boot e Thymeleaf para consumo de API de cadastro de vagas.

## 🚀 Tecnologias
- Java 17
- Spring Boot 3
- Thymeleaf
- Bootstrap 5
- REST API Integration

## ⚙️ Execução
```bash
mvn spring-boot:run
```
Acesse: [http://localhost:8080/vagas](http://localhost:8080/vagas)

## 📁 Estrutura
- `controller` → controladores MVC
- `service` → integração com API via RestTemplate
- `dto` → objetos de transferência de dados
- `templates` → páginas Thymeleaf
- `static` → CSS/JS

## 📜 Licença
MIT License
