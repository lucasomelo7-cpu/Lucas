package com.example.pi.controller;

import com.example.pi.model.Vaga;
import com.example.pi.service.VagaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/vagas")
public class VagaController {
    private final VagaService service;
    public VagaController(VagaService service) {
        this.service = service;
    }
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("vagas", service.listarTodas());
        return "list";
    }
    @GetMapping("/nova")
    public String novaVaga(Model model) {
        model.addAttribute("vaga", new Vaga());
        return "form";
    }
    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Vaga vaga) {
        service.salvar(vaga);
        return "redirect:/vagas";
    }
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("vaga", service.buscarPorId(id));
        return "form";
    }
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        service.deletar(id);
        return "redirect:/vagas";
    }
}