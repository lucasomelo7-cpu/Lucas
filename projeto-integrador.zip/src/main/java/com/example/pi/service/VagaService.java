package com.example.pi.service;

import com.example.pi.model.Vaga;
import com.example.pi.repository.VagaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class VagaService {
    private final VagaRepository repository;
    public VagaService(VagaRepository repository) {
        this.repository = repository;
    }
    public List<Vaga> listarTodas() {
        return repository.findAll();
    }
    public Vaga salvar(Vaga vaga) {
        return repository.save(vaga);
    }
    public Vaga buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }
    public void deletar(Long id) {
        repository.deleteById(id);
    }
}